#!/bin/bash
echo "🚀 AWS DevOps Professional Study Kit"
echo "===================================="
echo ""
echo "📱 Study Apps:"
echo "   cd apps && ./start_study_v2.sh"
echo ""
echo "📊 Export Materials:"
echo "   cd scripts && ./export_everything.sh"
echo ""
echo "📄 Documentation:"
echo "   open docs/README.md"
echo ""
echo "🎯 Choose your action:"
echo "1) Start studying (choose day)"
echo "2) Export all materials"
echo "3) View documentation"
echo ""
read -p "Enter choice (1-3): " choice

case $choice in
    1) 
        echo ""
        echo "📅 Which day do you want to study? (1-20)"
        echo "   Week 1: Days 1-7   (Questions 1-126)"
        echo "   Week 2: Days 8-14  (Questions 127-252)"
        echo "   Week 3: Days 15-20 (Questions 253-363)"
        echo ""
        read -p "Enter day (1-20) or press Enter for Day 1: " day
        day=${day:-1}
        cd apps && ./start_study_v2.sh $day
        ;;
    2) cd scripts && ./export_everything.sh ;;
    3) open docs/ ;;
    *) echo "Invalid choice" ;;
esac
