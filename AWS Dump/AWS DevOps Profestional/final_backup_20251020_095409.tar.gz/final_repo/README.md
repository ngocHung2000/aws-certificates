# 🚀 AWS DevOps Professional (DOP-C02) Study Kit

Complete study solution with 360 questions, multiple choice support, and various export formats.

## 📁 Structure

```
📂 final_repo/
├── 📱 apps/           # Study applications (20 days)
├── 💾 data/           # Question data (JSON)
├── 🔧 scripts/        # Generation & export scripts
├── 📄 docs/           # Documentation & guides
└── 📦 exports/        # Exported materials
```

## 🚀 Quick Start

```bash
# Interactive launcher
./start_here.sh

# Quick study specific day
./study.sh 5              # Study Day 5
./study.sh 15             # Study Day 15

# Manual launch
cd apps && ./start_study_v2.sh 10    # Day 10
```

## 📊 Content

- **360 questions** (257 single + 103 multiple choice)
- **20 study apps** with interactive features
- **Multiple export formats** (MD, JSON, CSV, Anki, Quizlet)
- **Practice tests** by week and question type

## 🎯 Features

✅ Multiple choice support with partial credit  
✅ Real-time progress tracking  
✅ Spaced repetition for wrong answers  
✅ Export to flashcards (Anki/Quizlet)  
✅ Offline study materials  
✅ 30-day study plan included  

Good luck with your AWS DevOps Professional exam! 🍀
